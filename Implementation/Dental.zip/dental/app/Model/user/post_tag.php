<?php

namespace App\Model\user;

use Illuminate\Database\Eloquent\Model;

class post_tag extends Model
{
    //
}
