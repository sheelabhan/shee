<?php

namespace App\Model\user;

use Illuminate\Database\Eloquent\Model;

class page extends Model
{
    public function getRouteKeyName(){
        return 'slug';
    }
}
