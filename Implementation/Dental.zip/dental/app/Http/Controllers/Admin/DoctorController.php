<?php

namespace App\Http\Controllers\Admin;

use App\doctors;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class DoctorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    public function index()
    {
        $doctors = doctors::all();
        return view('admin.doctor.show',compact('doctors'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.doctor.doctor');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'name'=>'required',
            'position' => 'required',
        ]);
        $this->validate($request, [

            'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',

        ]);


        $image = $request->file('image');

        $input['imagename'] = time().'.'.$image->getClientOriginalExtension();

        $destinationPath = public_path('/images');

        $image->move($destinationPath, $input['imagename']);
        $doctors = new doctors;
        $doctors->name = $request->name;
        $imageup = $input['imagename'];
        $doctors->image = $imageup;
        $doctors->position = $request->position;
        $doctors->skype = $request->skype;
        $doctors->twitter = $request->twitter;
        $doctors->facebook = $request->facebook;

        $doctors->slug = $request->slug;

        $doctors->save();

        return redirect(route('doctor.index'))->with('success', 'New doctor added successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $doctor = doctors::where('id',$id)->first();
        return view('admin.doctor.edit',compact('doctor'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'name'=>'required',
            'position' => 'required',
        ]);
        $this->validate($request, [

            'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',

        ]);


        $image = $request->file('image');

        $input['imagename'] = time().'.'.$image->getClientOriginalExtension();

        $destinationPath = public_path('/images');

        $image->move($destinationPath, $input['imagename']);
        $doctor = doctors::find($id);
        $doctor->name = $request->name;
        $imageup = $input['imagename'];
        $doctor->image = $imageup;

        $doctor->position = $request->position;
        $doctor->skype = $request->skype;
        $doctor->twitter = $request->twitter;
        $doctor->facebook = $request->facebook;
        $doctor->slug = $request->slug;

        $doctor->save();

        return redirect(route('doctor.index'))->with('success', 'Doctor details edited successfully!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        doctors::where('id',$id)->delete();
        return redirect()->back()->with('success', 'doctor deleted successfully!');
    }
}
