<?php

namespace App\Http\Controllers\User;

use App\Model\user\page;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PageController extends Controller
{
    public function page(page $page){

        return view('user.page',compact('page'));
    }
}
