<?php

namespace App\Http\Controllers\User;

use App\tourist;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class TouristController extends Controller
{
    public function tourist(tourist $tourist){

        return view('user.tourist',compact('tourist'));
    }


}
