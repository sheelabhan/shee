<?php

namespace App\Http\Controllers\User;

use App\Model\user\post;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class BlogController extends Controller
{
    public function index(){

        $posts = post::all();

        return view('user.main_blog',compact('posts'));
    }
}
