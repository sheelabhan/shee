<?php

namespace App\Http\Controllers\User;

use App\tourist;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class MainTouristController extends Controller
{
    public function index(){

        $tourists = tourist::all();

        return view('user.main_tourist',compact('tourists'));
    }
}
