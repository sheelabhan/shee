<?php

namespace App\Http\Controllers\User;

use App\doctors;
use App\Model\user\page;
use App\Model\user\post;
use App\tourist;
use App\user\slider;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class HomeController extends Controller
{
    public function index(){
        $posts = post::where('status',1)->get();
        $sliders = slider::all();
        $doctors = doctors::all();
        $pages = page::all();
        return view('user.blog',compact('posts','sliders','doctors','pages'));
    }
}
