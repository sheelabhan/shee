<?php

namespace App\user;

use Illuminate\Database\Eloquent\Model;

class slider extends Model
{
    //
}
